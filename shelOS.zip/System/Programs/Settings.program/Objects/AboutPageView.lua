Inherit = 'PageView'

